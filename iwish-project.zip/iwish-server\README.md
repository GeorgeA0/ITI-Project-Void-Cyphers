# i-Wish Server

Fulfils the "Server" half of the I-Wish spec (JETS Orange Belt):
Start/Stop, manipulate the database, handle client connections, handle
client requests.

## Design

- **Transport**: plain `Socket` + `ObjectInputStream`/`ObjectOutputStream`.
  The client sends one `com.iwish.protocol.Request` per call and blocks for
  one `com.iwish.protocol.Response` — see `com.iwish.protocol` (identical
  copy lives in the client project; both sides must keep it in sync since
  instances travel over the wire via Java serialization).
- **Concurrency**: `Server` accepts sockets on a dedicated thread and hands
  each one to a pooled `ClientHandler` thread, so multiple clients can be
  connected at once.
- **Database**: embedded SQLite (`iwish.db`, created automatically on first
  run) — one portable file, no separate DB server to install. Schema is in
  `Database.createSchema()`. DAOs (`UserDao`, `FriendDao`, `WishItemDao`,
  `NotificationDao`) hold all the SQL.
- **Notifications**: pull/polling model — the server stores notifications
  per user in the DB and `GET_NOTIFICATIONS` returns them; the client's
  existing `NotificationsController` already has a "Refresh" action to pull
  them. (A push model would need a second, server-initiated channel; the
  spec's "receive a notification" is satisfied by the client checking in.)

## Run it

```bash
mvn package
java -jar target/iwish-server.jar        # listens on port 5050
java -jar target/iwish-server.jar 6000   # or a custom port
```

Type `stop` + Enter on the console to shut it down cleanly. The Maven
Shade plugin bundles the sqlite-jdbc driver into the jar, so it's a single
file to run or hand in.

## Wiring up the client

In `iwish-client`, `AppContext` now tries `SocketClientService` (real
server) first and falls back to `MockClientService` (in-memory demo data)
if the server isn't reachable, so the GUI still runs standalone. Point it
at a different host/port with:

```bash
mvn javafx:run -Diwish.host=localhost -Diwish.port=5050
```

## Admin item seeding (spec item 12)

Per spec, catalog items can be added "via admin, or database insertion" —
with everyone's wish lists stored in the `wish_items` table, that's just:

```sql
INSERT INTO wish_items(name, price, contributed_amount, owner_username)
VALUES ('PlayStation 5', 499.0, 0, 'george');
```

against `iwish.db` (e.g. with the `sqlite3` CLI or any DB browser).
