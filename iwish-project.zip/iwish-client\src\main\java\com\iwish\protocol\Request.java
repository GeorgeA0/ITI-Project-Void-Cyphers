package com.iwish.protocol;

import java.io.Serializable;
import java.util.Arrays;

/**
 * One message the client sends to the server: which {@link Action} to
 * perform, plus its arguments (see {@link Action} for each action's expected
 * argument list). Must stay identical on both sides of the wire.
 */
public class Request implements Serializable {

    private static final long serialVersionUID = 1L;

    private final Action action;
    private final Object[] args;

    public Request(Action action, Object... args) {
        this.action = action;
        this.args = args;
    }

    public Action getAction() {
        return action;
    }

    public Object[] getArgs() {
        return args;
    }

    public String getString(int index) {
        return (String) args[index];
    }

    public double getDouble(int index) {
        return ((Number) args[index]).doubleValue();
    }

    public int getInt(int index) {
        return ((Number) args[index]).intValue();
    }

    @Override
    public String toString() {
        return action + Arrays.toString(args);
    }
}
