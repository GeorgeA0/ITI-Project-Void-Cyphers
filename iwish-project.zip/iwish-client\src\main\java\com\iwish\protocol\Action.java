package com.iwish.protocol;

/**
 * Every operation the client can ask the server to perform, over a single
 * socket connection. One {@link Request} carries exactly one Action plus its
 * arguments; the server answers with exactly one {@link Response}.
 *
 * IMPORTANT: this file must stay byte-for-byte identical (same package, same
 * enum constants) on both the client and the server project, since instances
 * of it travel between the two JVMs via Java serialization.
 */
public enum Action {
    REGISTER,               // args: [String username, String password]
    LOGIN,                  // args: [String username, String password]
    LOGOUT,                 // args: []
    GET_FRIENDS,            // args: []
    GET_PENDING_REQUESTS,   // args: []
    SEND_FRIEND_REQUEST,    // args: [String toUsername]
    ACCEPT_FRIEND_REQUEST,  // args: [String fromUsername]
    DECLINE_FRIEND_REQUEST, // args: [String fromUsername]
    REMOVE_FRIEND,          // args: [String friendUsername]
    GET_MY_WISHLIST,        // args: []
    ADD_WISH_ITEM,          // args: [String name, Double price]
    UPDATE_WISH_ITEM,       // args: [Integer itemId, String newName, Double newPrice]
    DELETE_WISH_ITEM,       // args: [Integer itemId]
    GET_FRIEND_WISHLIST,    // args: [String friendUsername]
    CONTRIBUTE,             // args: [Integer itemId, Double amount]
    GET_NOTIFICATIONS       // args: []
}
