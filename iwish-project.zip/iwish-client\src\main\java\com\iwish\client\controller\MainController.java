package com.iwish.client.controller;
import com.iwish.client.AppContext;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TabPane;

public class MainController {
    @FXML
    private Label welcomeLabel;
    @FXML
    private TabPane tabPane;
    @FXML
    private WishListController wishListController;
    @FXML
    private FriendsController friendsController;
    @FXML
    private NotificationsController notificationsController;

    @FXML
    private void initialize() {
        welcomeLabel.setText("Hi, " + AppContext.getService().getCurrentUsername() + "!");
        
        tabPane.getSelectionModel().selectedItemProperty().addListener((obs, oldTab, newTab) -> {
            if (newTab != null) {
                if (newTab.getText().equals("My Wish List") && wishListController != null) {
                    wishListController.refresh();
                } else if (newTab.getText().equals("Friends") && friendsController != null) {
                    friendsController.refresh();
                } else if (newTab.getText().equals("Notifications") && notificationsController != null) {
                    notificationsController.refresh();
                }
            }
        });
    }
    @FXML
    private void handleLogout() {
        AppContext.getService().logout();
        AppContext.switchScene("login.fxml", "i-Wish - Sign in");
    }
}
