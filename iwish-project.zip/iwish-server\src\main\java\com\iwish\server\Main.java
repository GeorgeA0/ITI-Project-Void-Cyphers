package com.iwish.server;

import com.iwish.server.net.Server;

/**
 * Runs the i-Wish server standalone: `mvn package` then
 * `java -jar target/iwish-server.jar [port]` (default port 5050).
 * Type "stop" + Enter on this console at any time to shut it down cleanly.
 */
public class Main {

    public static void main(String[] args) {
        int port = args.length > 0 ? Integer.parseInt(args[0]) : 5050;
        Server server = new Server(port);
        server.start();

        Runtime.getRuntime().addShutdownHook(new Thread(server::stop));

        System.out.println("Type 'stop' and press Enter to shut the server down.");
        try (var scanner = new java.util.Scanner(System.in)) {
            while (server.isRunning()) {
                String line = scanner.hasNextLine() ? scanner.nextLine() : "stop";
                if ("stop".equalsIgnoreCase(line.trim())) {
                    server.stop();
                    break;
                }
            }
        }
    }
}
