# i-Wish Project

This repository contains the i-Wish client and server applications.

## Prerequisites
- Java Development Kit (JDK) 17 or higher
- Apache Maven

## Running the Server
The server is a standard Java application with an embedded SQLite database. 

1. Open a terminal.
2. Navigate to the server directory:
   cd iwish-server
3. Build the server:
   mvn clean package
4. Run the generated JAR file:
   java -jar target/iwish-server.jar

*Note: If you get a 'Could not bind to port 5050' error, ensure no other instance of the server is running on that port.*

## Running the Client
The client is a JavaFX application.

1. Open a **new** terminal (keep the server running in the first one).
2. Navigate to the client directory:
   cd iwish-client
3. Run the client using the JavaFX Maven plugin:
   mvn javafx:run
