package com.iwish.protocol;

import java.io.Serializable;

/**
 * One message the server sends back for a {@link Request}: whether it
 * succeeded, an optional payload (a List, a Boolean, a String...) and an
 * optional human-readable message for the GUI to show. Must stay identical
 * on both sides of the wire.
 */
public class Response implements Serializable {

    private static final long serialVersionUID = 1L;

    private final boolean success;
    private final Object data;
    private final String message;

    private Response(boolean success, Object data, String message) {
        this.success = success;
        this.data = data;
        this.message = message;
    }

    public static Response ok(Object data) {
        return new Response(true, data, null);
    }

    public static Response ok() {
        return new Response(true, null, null);
    }

    public static Response fail(String message) {
        return new Response(false, null, message);
    }

    public boolean isSuccess() {
        return success;
    }

    @SuppressWarnings("unchecked")
    public <T> T getData() {
        return (T) data;
    }

    public String getMessage() {
        return message;
    }
}
