package com.iwish.client.model;

import java.io.Serializable;

/**
 * Mirrors com.iwish.client.model.User in the client project field-for-field.
 * Objects of this class travel over the socket via Java serialization, so
 * this copy must stay in sync with the client's version (same package, same
 * fields, both Serializable).
 */
public class User implements Serializable {

    private static final long serialVersionUID = 1L;

    private String username;

    public User(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public String toString() {
        return username;
    }
}
